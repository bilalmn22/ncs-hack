import RegisterForm from "../../ui/register/influencer/register-form";

function Page() {
  return <RegisterForm />;
}

export default Page;
