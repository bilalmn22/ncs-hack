import RegisterForm from "../../ui/register/company/register-form";

function Page() {
  return <RegisterForm />;
}

export default Page;
