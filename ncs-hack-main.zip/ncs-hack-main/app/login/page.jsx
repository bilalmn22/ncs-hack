import LoginForm from "../ui/login/login-form";

function Page() {
  return <LoginForm />;
}

export default Page;
